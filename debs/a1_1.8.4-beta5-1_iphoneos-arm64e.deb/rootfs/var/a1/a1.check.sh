#
#
# a1.check.sh
# Created by AD on 15/12/25
# Copyright (c) 2025 AD All rights reserved.
#
#

rootless="/var/jb/a1/rootless"
roothide="/rootfs/var/a1/roothide"
rootful="/var/a1/rootful"

if [ -f "$rootless" ]; then
    jb="/var/jb" # rootless
    jb_a1="$jb/a1" # rootless
    a1_expand="$jb_a1/a1.expand"
elif [ -f "$roothide" ]; then
    jb="" # roothide
    jb_a1="$jb/rootfs/var/a1" # roothide
    a1_expand="$jb_a1/a1.expand"
elif [ -f $rootful ]; then
    jb="" # rootful
    jb_a1="$jb/var/a1" # rootful
    a1_expand="$jb_a1/a1.expand"
fi

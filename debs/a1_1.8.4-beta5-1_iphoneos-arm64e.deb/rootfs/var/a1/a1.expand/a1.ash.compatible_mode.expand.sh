# Apply priority to specific process list
# 核心规则：
# 1. 高优列表（target_priority=0）：不读nice值，直接遍历执行设置（不跳过）
# 2. 低优列表（target_priority=39）：读nice值，一致则跳过，不一致则设置
apply_priority_to_list() {
    local target_priority=$1  # 配置文件中的目标优先级（0=高优，39=低优）
    shift
    local processes=("$@")
    local count=0
    local total_attempts=0
    local skip_count=0

    # 1. 基础配置（语法错误零容忍）
    local LOG_LEVEL=2
    local TOOL="$jb/usr/bin"
    local target_nice=$((target_priority - 20))
    [ "$target_nice" -lt -20 ] && target_nice=-20
    [ "$target_nice" -gt 19 ] && target_nice=19

    # 2. 工具可用性检测
    local has_jetsamctl=$($TOOL/command -v $TOOL/jetsamctl &>/dev/null && echo 1 || echo 0)
    local has_jetsamctl_=$([ -x "$TOOL/jetsamctl_" ] && echo 1 || echo 0)
    local has_bundle_pid=$([ -x "$TOOL/bundle_pid" ] && echo 1 || echo 0)

    # 3. 输出标题（参考扩展脚本风格）
    if [ "$target_priority" -eq 0 ]; then
        echo "A1 高優進程優先級設置執行中..."
        echo "目標優先級：$target_priority"
    else
        echo "A1 低優進程優先級設置執行中..."
        echo "目標優先級：$target_priority → 對應 Nice 值：$target_nice"
    fi
    echo "待處理進程數量：${#processes[@]}"
    echo "------------------------"

    for process in "${processes[@]}"; do
        local pids=()

        # PID抓取+严格去重（避免同一PID重复处理）
        if $TOOL/echo "$process" | perl -ne 'exit 1 unless /^[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/'; then
            [ "$has_bundle_pid" -eq 1 ] && {
                local bp_pid=$($TOOL/bundle_pid "$process" 2>/dev/null)
                [ "$bp_pid" -gt 0 ] 2>/dev/null && pids+=("$bp_pid")
            }
            local ps_pids=$($ps -A -o pid=,command= | $TOOL/grep -E "$process" | $TOOL/grep -v "$TOOL/grep" | $TOOL/awk '{print $1}')
            declare -A pid_map  # 关联数组彻底去重
            for pid in "${pids[@]}" $ps_pids; do
                [ -n "$pid" ] && pid_map["$pid"]=1
            done
            pids=("${!pid_map[@]}")
            unset pid_map
        else
            local exact_pid=$($ps -A -o pid=,comm= | $TOOL/awk -v p="$process" '$2 == p {print $1; exit}')
            local fuzzy_pid=$($ps -A -o pid=,command= | $TOOL/grep -E "[ /]$process($| )" | $TOOL/grep -v "$TOOL/grep" | $TOOL/awk '{print $1}' | head -1)
            declare -A pid_map
            [ -n "$exact_pid" ] && pid_map["$exact_pid"]=1
            [ -n "$fuzzy_pid" ] && pid_map["$fuzzy_pid"]=1
            pids=("${!pid_map[@]}")
            unset pid_map
        fi

        [ ${#pids[@]} -eq 0 ] && continue

        for pid in "${pids[@]}"; do
            if ! $ps -p "$pid" >/dev/null 2>&1; then
                continue
            fi
            ((total_attempts++))
            local set_success=0  # 每个PID独立计数标记

            # 低优列表：读取nice值+跳过逻辑
            if [ "$target_priority" -eq 39 ]; then
                current_nice=$($ps -o ni= -p "$pid" 2>/dev/null | \
                    $TOOL/tr -d '[:space:][:alpha:][:punct:]' | \
                    $TOOL/awk '{print $0 + 0}')
                if echo "$current_nice" | perl -ne 'exit 1 unless /^-?\d+$/ && $_ >= -20 && $_ <= 19'; then
                    if [ "$current_nice" -eq "$target_nice" ]; then
                        echo "  跳過 $process (PID:$pid)：Nice 值 $current_nice 與目標一致"
                        ((skip_count++))
                        continue
                    fi
                fi
            fi

            # 执行设置：成功后立即跳出，避免重复计数（核心修复）
            # 方案1：jetsamctl_（优先）
            if [ "$has_jetsamctl_" -eq 1 ] && [ "$set_success" -eq 0 ]; then
                if $TOOL/jetsamctl_ -p "$target_priority" "$pid" >/dev/null 2>&1; then
                    if [ "$target_priority" -eq 0 ]; then
                        echo "  設置成功 $process (PID:$pid) - jetsamctl_"
                    else
                        local new_nice=$($ps -o ni= -p "$pid" 2>/dev/null | $TOOL/tr -d '[:space:]' | $TOOL/awk '{print $0 + 0}')
                        echo "  設置成功 $process (PID:$pid) - jetsamctl_（Nice: ${current_nice:-?}→$target_nice）"
                    fi
                    ((count++)) && set_success=1 && continue  # 成功即跳出，不执行后续方案
                fi
            fi

            # 方案2：jetsamctl（兜底）
            if [ "$has_jetsamctl" -eq 1 ] && [ "$set_success" -eq 0 ]; then
                if $TOOL/jetsamctl set priority "$pid" "$target_priority" >/dev/null 2>&1; then
                    if [ "$target_priority" -eq 0 ]; then
                        echo "  設置成功 $process (PID:$pid) - jetsamctl"
                    else
                        local new_nice=$($ps -o ni= -p "$pid" 2>/dev/null | $TOOL/tr -d '[:space:]' | $TOOL/awk '{print $0 + 0}')
                        echo "  設置成功 $process (PID:$pid) - jetsamctl（Nice: ${current_nice:-?}→$target_nice）"
                    fi
                    ((count++)) && set_success=1 && continue
                fi
            fi

            # 方案3：renice（最终兜底）
            if [ "$set_success" -eq 0 ]; then
                local renice_val=$((target_priority - 20))
                [ "$renice_val" -lt -20 ] && renice_val=-20
                [ "$renice_val" -gt 19 ] && renice_val=19
                if $TOOL/renice "$renice_val" -p "$pid" >/dev/null 2>&1; then
                    if [ "$target_priority" -eq 0 ]; then
                        echo "  設置成功 $process (PID:$pid) - renice"
                    else
                        local new_nice=$($ps -o ni= -p "$pid" 2>/dev/null | $TOOL/tr -d '[:space:]' | $TOOL/awk '{print $0 + 0}')
                        echo "  設置成功 $process (PID:$pid) - renice（Nice: ${current_nice:-?}→$target_nice）"
                    fi
                    ((count++)) && set_success=1
                fi
            fi
        done
    done

    # 强制校正：确保成功设置≤总尝试（双重保险）
    if [ "$count" -gt "$total_attempts" ]; then
        count="$total_attempts"
    fi

    # 输出总结
    echo "------------------------"
    if [ "$target_priority" -eq 0 ]; then
        echo "A1 高優進程優先級設置完成"
    else
        echo "A1 低優進程優先級設置完成"
    fi
    echo "  總嘗試：$total_attempts | 成功設置：$count | 跳過：$skip_count"
    echo ""
    return $((total_attempts - count))
}
# 測試文件
# echo "1234567890"
# echo "test（測試文件)"
: '
apply_priority_to_list() {
    local priority=$1
    shift
    local processes=("$@")
    
    local count=0
    
    for process in "${processes[@]}"; do
        echo "    Setting priority $priority for: $process"
        
        SUCCESS=0

        # 嘗試標準 jetsamctl
        if $jb/usr/bin/command -v jetsamctl &>/dev/null; then
            if $jb/usr/bin/jetsamctl -p "$priority" "$process" >/dev/null 2>&1; then
                echo "      ✓ Set via jetsamctl (supports Bundle ID)"
                ((count++))
                SUCCESS=1
            fi
        fi

        if [ $SUCCESS -eq 0 ]; then
            PID=""
            # 获取PID
            if echo "$process" | perl -ne 'exit 1 unless /^[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/'; then
                # Bundle ID 转為 PID
                if [ -x "$jb/usr/bin/bundle_pid" ]; then
                    PID=$($jb/usr/bin/bundle_pid "$process" 2>/dev/null)
                    # 改用 perl 的正則表達式
                    if echo "$PID" | perl -ne 'exit 1 unless /^\d+$/ && $_ > 0'; then
                        echo "      Bundle ID found: $process -> PID:$PID"
                    else
                        PID=""
                        echo "      Bundle ID not found: $process"
                        continue
                    fi
                else
                    echo "      bundle_pid not available"
                    continue
                fi
            else
                # 普通進程名查找
                PID=$($ps -A -o pid=,comm= | $jb/usr/bin/awk -v p="$process" '$2 == p {print $1; exit}')
                
                # 模糊查找 Fallback
                if [ -z "$PID" ]; then
                    PID=$($ps -A -o pid=,command= | $jb/usr/bin/grep -E "[ /]$process($| )" | $jb/usr/bin/awk '{print $1}' | head -1)
                fi
                
                if [ -n "$PID" ] && [ "$PID" -gt 0 ] 2>/dev/null; then
                    echo "      Process found: $process -> PID:$PID"
                else
                    echo "      Process not found: $process"
                    continue
                fi
            fi

            # 嘗試 jetsamctl_ (針對 PID)
            if [ -n "$PID" ] && [ -x "$jb/usr/bin/jetsamctl_" ]; then
                if $jb/usr/bin/jetsamctl_ -p "$priority" "$PID" >/dev/null 2>&1; then
                    echo "        ✓ Set via jetsamctl_"
                    ((count++))
                    SUCCESS=1
                else
                    echo "        jetsamctl_ failed for PID:$PID"
                fi
            fi

            # 嘗試 renice
            if [ $SUCCESS -eq 0 ] && [ -n "$PID" ]; then
                renice_value=$((priority - 20))
                
                if [ "$renice_value" -lt -20 ]; then renice_value=-20; fi
                if [ "$renice_value" -gt 19 ]; then renice_value=19; fi

                if $jb/usr/bin/renice $renice_value -p "$PID" >/dev/null 2>&1; then
                    echo "        ✓ Set via renice"
                    ((count++))
                    SUCCESS=1
                else
                    echo "        All methods failed for $process"
                fi
            fi
        fi
    done
    
    echo "  Adjusted $count processes to priority $priority"
}
'
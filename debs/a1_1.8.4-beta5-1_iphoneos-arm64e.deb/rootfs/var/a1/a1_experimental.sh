#!/bin/sh -

: '

Created by AD on 6/12/25
Copyright (c) 2025 AD All rights reserved.

'

# 誤刪這是環境檢測
rootless="/var/jb/a1/rootless"
roothide="/rootfs/var/a1/roothide"
rootful="/var/a1/rootful"

if [ -f "$rootless" ]; then
    jb="/var/jb" # rootless
    jb_a1="$jb/a1" # rootless
elif [ -f "$roothide" ]; then
    jb="" # roothide
    jb_a1="$jb/rootfs/var/a1" # roothide
    a1_expand="$jb_a1/a1.expand"
elif [ -f $rootful ]; then
    jb="" # rootful
    jb_a1="$jb/var/a1" # rootful
fi


$jb/usr/sbin/sysctl kern.vm_page_free_min=20000
$jb/usr/sbin/sysctl kern.vm_page_free_reserved=256
$jb/usr/sbin/sysctl kern.memorystatus_kill_on_sustained_pressure_delay_ms=86400000
$jb/usr/sbin/sysctl kern.vm_max_delayed_work_limit=64
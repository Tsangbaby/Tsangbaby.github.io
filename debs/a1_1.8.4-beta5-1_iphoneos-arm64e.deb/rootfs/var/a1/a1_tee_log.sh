#!/usr/bin/env bash
# a1_tee_log.sh

: '

Created by AD on 7/12/25
Copyright (c) 2025 AD All rights reserved.

'

# 誤刪這是環境檢測
rootless="/var/jb/a1/rootless"
roothide="/rootfs/var/a1/roothide"
rootful="/var/a1/rootful"

if [ -f "$rootless" ]; then
    jb="/var/jb" # rootless
    jb_a1="$jb/a1" # rootless
elif [ -f "$roothide" ]; then
    jb="" # roothide
    jb_a1="$jb/rootfs/var/a1" # roothide
elif [ -f $rootful ]; then
    jb="" # rootful
    jb_a1="$jb/var/a1" # rootful
fi

tee "$jb_a1/a1.log" < /dev/null > /dev/null
tee "$jb_a1/a1error.log" < /dev/null > /dev/null

echo "The log has been cleaned up."
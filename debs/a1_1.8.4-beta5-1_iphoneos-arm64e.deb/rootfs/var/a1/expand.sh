#!/bin/bash

#
#
# official.a1.ad.expand.sh
# Created by AD on 15/12/25
# Copyright (c) 2025 AD All rights reserved.
#
#

# 誤刪這是環境檢測
rootless="/var/jb/a1/rootless"
roothide="/rootfs/var/a1/roothide"
rootful="/var/a1/rootful"

if [ -f "$rootless" ]; then
    jb="/var/jb" # rootless
    jb_a1="$jb/a1" # rootless
    a1_expand="$jb_a1/a1.expand"
elif [ -f "$roothide" ]; then
    jb="" # roothide
    jb_a1="$jb/rootfs/var/a1" # roothide
    a1_expand="$jb_a1/a1.expand"
elif [ -f $rootful ]; then
    jb="" # rootful
    jb_a1="$jb/var/a1" # rootful
    a1_expand="$jb_a1/a1.expand"
fi

export jb a1_expand jb_a1

# source $jb_expand/a1.expand/1.sh # 這是測試文件,不用加載

source $a1_expand/official.a1.ad.expand.sh # 官方擴展模組

#####################################
############ 用戶擴展模組 #############
#####################################



